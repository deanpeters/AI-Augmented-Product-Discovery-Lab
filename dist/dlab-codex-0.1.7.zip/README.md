# AI-Augmented Product Discovery Lab

Ten discovery skills with matching prompts, templates and worked/weak examples.
Start at the decision you need to make; earlier artifacts are optional.
Choose Guided, Context dump or Best guess and stop for a human decision.
Synthetic examples generate hypotheses, not customer evidence.

The skills live in skills/, prompt equivalents in prompts/, and the motion list
in docs/catalog.json. Optional Productside references retain their attribution.
Original lab materials: CC BY-NC-SA 4.0; Productside assets are excluded from
that license. See LICENSE and docs/PROVENANCE.md.

Installation and demo companion:
https://github.com/deanpeters/AI-Augmented-Product-Discovery-Lab/blob/main/docs/CODEX-PLUGIN.md
https://github.com/deanpeters/AI-Augmented-Product-Discovery-Lab/blob/main/examples/kickoff-prompts.md

This kit has no MCP server, hooks, credentials or autonomous chain runner.
