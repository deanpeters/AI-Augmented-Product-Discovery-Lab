# Value Prop vs. Differentiation 2x2: fallback illustration

SYNTHETIC illustrative seed, not a rehearsal receipt or an approved artifact.

Open the [complete worked example](../skills/dlab-step05-value-prop-differentiation/examples/worked-example.md) for this motion's artifact and handoff. Read it before choosing a next step.

Recovery line: “This is a synthetic illustration of the motion. It is not customer evidence.”
